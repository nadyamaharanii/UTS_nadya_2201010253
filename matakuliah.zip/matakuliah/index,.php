<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CRUD Mata Kuliah</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>CRUD Mata Kuliah</h1>
    <a href="courses.php" class="btn btn-primary">Daftar Mata Kuliah</a>
  </div>
</body>

</html>
