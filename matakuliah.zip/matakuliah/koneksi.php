<?php
$host = "127.0.0.1"; // Nama host database
$username = "root"; // Nama pengguna database
$password = ""; // Password pengguna database
$dbname = "matakuliah"; // Nama database

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Koneksi berhasil!";
} catch (PDOException $e) {
    echo "Koneksi gagal: " . $e->getMessage();
}
?>
