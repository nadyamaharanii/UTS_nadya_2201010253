<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar Mata Kuliah</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Daftar Mata Kuliah</h1>
    <a href="add_course.php" class="btn btn-primary">Tambah Mata Kuliah</a>
    <a href="index.php" class="btn btn-danger">Home</a>
    <a href="biodata.php" class="btn btn-success">Tentang Mahasiswa</a>
    <table class="table mt-4">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Kode</th>
          <th scope="col">Nama</th>
          <th scope="col">Semester</th>
          <th scope="col">Program Jurusan</th>
          <th scope="col">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Koneksi ke database
        $conn = mysqli_connect("127.0.0.1", "root", "", "matakuliah");

        // Query untuk mendapatkan data mata kuliah
        $query = "SELECT * FROM course";
        $result = mysqli_query($conn, $query);

        // Looping untuk menampilkan data mata kuliah
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<tr>";
          echo "<th scope='row'>" . $row['id'] . "</th>";
          echo "<td>" . $row['kodematkul'] . "</td>";
          echo "<td>" . $row['namamatkul'] . "</td>";
          echo "<td>" . $row['semester'] . "</td>";
          echo "<td>" . $row['programjurusan'] . "</td>";
          echo "<td>";
          echo "<a href='course_detail.php?id=" . $row['id'] . "' class='btn btn-sm btn-primary'>Detail</a>";
          echo "<a href='edit_course.php?id=" . $row['id'] . "' class='btn btn-sm btn-success'>Edit</a>";
          echo "<a href='delete_course.php?id=" . $row['id'] . "' class='btn btn-sm btn-danger'>Hapus</a>";
          echo "</td>";
          echo "</tr>";
        }

        // Menutup koneksi database
        mysqli_close($conn);
        ?>
      </tbody>
    </table>
  </div>
</body>

</html>
