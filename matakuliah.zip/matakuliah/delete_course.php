<?php
// Koneksi ke database
$conn = mysqli_connect("127.0.0.1", "root", "", "matakuliah");

// Mendapatkan ID mata kuliah dari parameter URL
$id = $_GET['id'];

// Query untuk menghapus mata kuliah berdasarkan ID
$query = "DELETE FROM course WHERE id = $id";
$result = mysqli_query($conn, $query);

// Mengecek apakah query berhasil dijalankan
if ($result) {
  // Redirect ke halaman daftar mata kuliah jika berhasil
  header("Location: courses.php");
} else {
  // Menampilkan pesan error jika gagal
  echo "Error: " . mysqli_error($conn);
}

// Menutup koneksi database
mysqli_close($conn);
?>
