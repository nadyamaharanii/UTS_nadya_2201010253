<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Biodata Mahasiswa</title>
  <!-- Link CSS Bootstrap -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Inline CSS untuk warna dasar -->
  <style>
    body {
      background-color: #e8d6f7;
    }
  </style>
</head>

<body>

  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
   <a href="add_course.php" class="btn btn-primary">Tambah Mata Kuliah</a>
    <a href="index.php" class="btn btn-danger">Home</a>
        <h3 class="text-center">Biodata Mahasiswa</h3>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-4 text-center">
            <img src="img/ram.jpg" class="img-fluid small-square mx-auto" alt="Foto Profil" width="100px;">
          </div>
          <div class="col-md-8">
            <h5>Nama Mahasiswa: Ni Made Nadya Maharani</h5>
            <h5>NIM: 2201010253</h5>
            <h5>Jurusan: Teknik Informatika</h5>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Script JS Bootstrap -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
