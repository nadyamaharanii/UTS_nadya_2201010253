<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Mata Kuliah</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Edit Mata Kuliah</h1>
    <?php
    // Koneksi ke database
    $conn = mysqli_connect("127.0.0.1", "root", "", "matakuliah");

    // Mendapatkan ID mata kuliah dari parameter URL
    $id = $_GET['id'];

    // Query untuk mendapatkan data mata kuliah berdasarkan ID
    $query = "SELECT * FROM course WHERE id = $id";
    $result = mysqli_query($conn, $query);

    // Menampilkan form untuk mengedit mata kuliah
    if ($row = mysqli_fetch_assoc($result)) {
      ?>
      <form action="update_course.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <div class="form-group">
          <label for="kode">Kode:</label>
          <input type="text" class="form-control" id="kode" name="kode" value="<?php echo $row['kodematkul']; ?>" required>
        </div>
        <div class="form-group">
          <label for="nama">Nama:</label>
          <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $row['namamatkul']; ?>" required>
        </div>
        <div class="form-group">
          <label for="semester">Semester:</label>
          <input type="number" class="form-control" id="semester" name="semester" value="<?php echo $row['semester']; ?>" required>
        </div>
        <div class="form-group">
          <label for="program_jurusan">Program Jurusan:</label>
          <input type="text" class="form-control" id="program_jurusan" name="program_jurusan" value="<?php echo $row['programjurusan']; ?>" required>
        </div>
        <button type="submit" class="btn btn-warning">Simpan</button>
      </form>
    <?php
    } else {
      echo "Data mata kuliah tidak ditemukan.";
    }

    // Menutup koneksi database
    mysqli_close($conn);
    ?>
    <a href="courses.php" class="btn btn-secondary">Kembali</a>
  </div>
</body>

</html>
