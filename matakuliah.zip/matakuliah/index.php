<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CRUD Mata Kuliah</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>CRUD Mata Kuliah</h1>
    <a href="courses.php" class="btn btn-primary">Daftar Mata Kuliah</a>
    <a href="biodata.php" class="btn btn-success">Tentang Mahasiswa</a>
<div class="card-body">
        <p>CRUD merupakan singkatan dari Create, Read, Update, dan Delete, yang merupakan operasi dasar dalam pengelolaan data pada aplikasi. Dengan menggunakan operasi CRUD, Anda dapat memanipulasi data yang tersimpan dalam database.</p>
        <p>Operasi Create digunakan untuk membuat data baru dalam database. Operasi Read digunakan untuk membaca atau mengambil data dari database. Operasi Update digunakan untuk mengubah atau memperbarui data yang sudah ada dalam database. Operasi Delete digunakan untuk menghapus data dari database.</p>
        <p>CRUD sering digunakan dalam pengembangan aplikasi web, termasuk dalam manajemen data seperti pengelolaan pengguna, produk, pesanan, dan sebagainya. Dengan mengimplementasikan operasi CRUD, Anda dapat melakukan manipulasi data secara efektif dan efisien.</p>
      </div>

  </div>
</body>

</html>
