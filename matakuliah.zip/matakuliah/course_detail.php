<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Detail Mata Kuliah</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Detail Mata Kuliah</h1>
    <?php
    // Koneksi ke database
    $conn = mysqli_connect("127.0.0.1", "root", "", "matakuliah");

    // Mendapatkan ID mata kuliah dari parameter URL
    $id = $_GET['id'];

    // Query untuk mendapatkan data mata kuliah berdasarkan ID
    $query = "SELECT * FROM course WHERE id = $id";
    $result = mysqli_query($conn, $query);

    // Menampilkan data mata kuliah
    if ($row = mysqli_fetch_assoc($result)) {
      echo "<p><strong>Kode:</strong> " . $row['kodematkul'] . "</p>";
      echo "<p><strong>Nama:</strong> " . $row['namamatkul'] . "</p>";
      echo "<p><strong>Semester:</strong> " . $row['semester'] . "</p>";
      echo "<p><strong>Program Jurusan:</strong> " . $row['programjurusan'] . "</p>";
    } else {
      echo "Data mata kuliah tidak ditemukan.";
    }

    // Menutup koneksi database
    mysqli_close($conn);
    ?>
    <a href="courses.php" class="btn btn-primary">Kembali</a>
  </div>
</body>

</html>
