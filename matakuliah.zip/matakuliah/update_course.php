<?php
// Koneksi ke database
$conn = mysqli_connect("127.0.0.1", "root", "", "matakuliah");

// Mendapatkan data dari form
$id = $_POST['id'];
$kode = $_POST['kode'];
$nama = $_POST['nama'];
$semester = $_POST['semester'];
$program_jurusan = $_POST['program_jurusan'];

// Query untuk memperbarui mata kuliah
$query = "UPDATE course SET kodematkul = '$kode', namamatkul = '$nama', semester = $semester, programjurusan = '$program_jurusan' WHERE id = $id";
$result = mysqli_query($conn, $query);

// Mengecek apakah query berhasil dijalankan
if ($result) {
  // Redirect ke halaman daftar mata kuliah jika berhasil
  header("Location: courses.php");
} else {
  // Menampilkan pesan error jika gagal
  echo "Error: " . mysqli_error($conn);
}

// Menutup koneksi database
mysqli_close($conn);
?>
