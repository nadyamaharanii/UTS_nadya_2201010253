<?php
// Koneksi ke database
$conn = mysqli_connect("127.0.0.1", "root", "", "matakuliah");

// Mendapatkan data dari form
$kode = $_POST['kode'];
$nama = $_POST['nama'];
$semester = $_POST['semester'];
$program_jurusan = $_POST['program_jurusan'];

// Query untuk menambahkan mata kuliah ke database
$query = "INSERT INTO course (kodematkul, namamatkul, semester, programjurusan) VALUES ('$kode', '$nama', $semester, '$program_jurusan')";
$result = mysqli_query($conn, $query);

// Mengecek apakah query berhasil dijalankan
if ($result) {
  // Redirect ke halaman daftar mata kuliah jika berhasil
  header("Location: courses.php");
} else {
  // Menampilkan pesan error jika gagal
  echo "Error: " . mysqli_error($conn);
}

// Menutup koneksi database
mysqli_close($conn);
?>
