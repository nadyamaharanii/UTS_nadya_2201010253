<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Mata Kuliah</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Tambah Mata Kuliah</h1>
    <!-- Form untuk menambahkan mata kuliah -->
    <form action="create_course.php" method="POST">
      <div class="form-group">
        <label for="kode">Kode:</label>
        <input type="text" class="form-control" id="kode" name="kode" required>
      </div>
      <div class="form-group">
        <label for="nama">Nama:</label>
        <input type="text" class="form-control" id="nama" name="nama" required>
      </div>
      <div class="form-group">
        <label for="semester">Semester:</label>
        <input type="number" class="form-control" id="semester" name="semester" required>
      </div>
      <div class="form-group">
        <label for="program_jurusan">Program Jurusan:</label>
        <input type="text" class="form-control" id="program_jurusan" name="program_jurusan" required>
      </div>
      <button type="submit" class="btn btn-warning">Tambah</button>
      <a href="courses.php" class="btn btn-primary">Daftar Mata Kuliah</a>
    </form>
  </div>
</body>

</html>
